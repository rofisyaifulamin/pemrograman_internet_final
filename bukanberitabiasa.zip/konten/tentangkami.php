<div class="tambahan" align="justify">
<h1>Tentang Web Bukan Berita Biasa (BBB)</h1>
<h2  class="sub-header">Sekilas tentang BBB</h2>
<h4>Web bukan berita biasa adalah web pengumpul berita online dari berbagai sumber yang dapat digunakan sebagai sarana masyarakat atau pembaca berita online untuk membrikan nilai keaktualan pada sebuah berita yang dimuat.
	<br><br>Dengan adanya web <strong><i>BBB</i></strong> ini diharapkan masyarakat sebagai pembaca dapat lebih bijak dan tanggap dalam menyikapi berita yang ada. 
	<br><br> Untuk memajukan web ini silahkan kirimkan kritik dan saran melaui fitur <a href="?tampil=kontak">Kontak Kami</a>. 
	<br><br></h4>
<h4>Selamat Membaca.</h4>
</div>