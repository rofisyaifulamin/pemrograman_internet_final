<?php
	$host	= "localhost";
	$user	= "root";
	$pass	= "";
	$db		= "dbbukanberitabiasa";
	
	$mysqli = new mysqli($host, $user, $pass, $db);
?>