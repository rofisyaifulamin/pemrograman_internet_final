<?php
	if(!defined("INDEX")) die("---");
?>

<h2  class="sub-header">Selamat Datang di Halaman Administrator</h2>
<h4>Pilih salah satu menu untuk mengatur website!</h4>