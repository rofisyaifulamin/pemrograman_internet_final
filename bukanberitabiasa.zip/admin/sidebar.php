<?php
	if(!defined("INDEX")) die("---");
?>
<ul class="nav nav-sidebar">
        <li><a href="admin.php">		Beranda	</a></li>
		<li><a href="?tampil=berita">	Berita	</a></li>
		<li><a href="?tampil=kategori">	Kategori</a></li>
		<li><a href="?tampil=pesan">	Pesan	</a></li>
		<li><a href="?tampil=komentar">	Komentar </a></li>
</ul>
